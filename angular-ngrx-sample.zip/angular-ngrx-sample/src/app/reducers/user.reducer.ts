import { createReducer, on } from '@ngrx/store';
import { addUser } from '../actions/user.actions';
import { User } from '../model/users.model';

export const initialState: ReadonlyArray<string> = [];

export const UserReducer = createReducer(
  initialState,
  on(addUser, (state, { username }) => {
    return [...state, username];
  })
);
