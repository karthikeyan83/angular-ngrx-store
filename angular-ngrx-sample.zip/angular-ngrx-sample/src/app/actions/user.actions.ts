import { createAction, props } from '@ngrx/store';
import { User } from '../model/users.model';

export const addUser = createAction(
  'Add User',
   props<{ username: string }>()
);
