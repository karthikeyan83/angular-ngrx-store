import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { UserReducer } from './reducers/user.reducer';
import { StoreModule } from '@ngrx/store';
import { UserListComponent } from './user-list/user-list.component';
import { UserList1Component } from './user-list1/user-list1.component';


@NgModule({
  declarations: [
    AppComponent,
    UserListComponent,
    UserList1Component
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    StoreModule.forRoot({ users: UserReducer })
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
