import { Component, OnInit } from '@angular/core';
import { Store } from '@ngrx/store';
import { selectUsers } from '../selectors/users.selectors';

@Component({
  selector: 'app-user-list1',
  templateUrl: './user-list1.component.html',
  styleUrls: ['./user-list1.component.css']
})
export class UserList1Component implements OnInit {

  users:any;
  constructor(private store: Store) {}
  ngOnInit(): void {
    this.store.select(selectUsers).subscribe(data => {
          this.users = data
    });
  }
}
